<?php
namespace app\forms;

use std, gui, framework, app;


class done extends AbstractForm
{

    /**
     * @event imageAlt.click-Left 
     */
    function doImageAltClickLeft(UXMouseEvent $e = null)
    {    
        
    }



}
